package com.fzbank.newsrewrite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsRewriteApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsRewriteApplication.class, args);
	}

}
